import logo from "./uberLogo.svg";
import bg from "./bg-screen.jpg";
import map from "./Map.svg";

export const assets = {
  logo: logo,
  bg: bg,
  map: map,
};
