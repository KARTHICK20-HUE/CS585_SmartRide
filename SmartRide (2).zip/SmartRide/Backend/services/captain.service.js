const captainModel = require("../models/captain.model");

module.exports.createCaptain = async ({
  firstname,
  lastname,
  email,
  password,
  vehicleName,
  color,
  plate,
  capacity,
  vehicleType,
}) => {
  if (
    !firstname ||
    !email ||
    !password ||
    !vehicleName ||
    !color ||
    !plate ||
    !capacity ||
    !vehicleType
  ) {
    throw new Error("All fields are required");
  }
  const captain = new captainModel({
    fullname: {
      firstname,
      lastname,
    },
    email,
    password,
    vehicle: {
      name: vehicleName,
      color,
      plate,
      capacity,
      vehicleType,
    },
    status: "online",
    earnings: 0,
  });
  return captain;
};
