const axios = require("axios");
const captainModel = require("../models/captain.model");

module.exports.getAddressCoordinate = async (address) => {
  const apiKey = process.env.GOOGLE_MAPS_API_KEY;
  const url = `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(
    address
  )}&key=${apiKey}`;

  try {
    const response = await axios.get(url);
    if (response.data.status === "OK") {
      const location = response.data.results[0].geometry.location;
      return {
        ltd: location.lat,
        lng: location.lng,
      };
    } else {
      throw new Error("Unable to fetch coordinates");
    }
  } catch (error) {
    console.error(error);
    throw error;
  }
};

module.exports.getDistanceTime = async (origin, destination) => {
  if (!origin || !destination) {
    throw new Error("Origin and destination are required");
  }
  const apiKey = process.env.GOOGLE_MAPS_API_KEY;
  const url = `https://maps.googleapis.com/maps/api/distancematrix/json?origins=${encodeURIComponent(
    origin
  )}&destinations=${encodeURIComponent(destination)}&key=${apiKey}`;

  try {
    const response = await axios.get(url);
    if (response.data.status === "OK") {
      if (response.data.rows[0].elements[0].status === "ZERO_RESULTS") {
        throw new Error("Location not found");
      }
      return response.data.rows[0].elements[0];
    } else {
      throw new Error("Unable to fetch distance and time");
    }
  } catch (error) {
    console.error(error);
    throw error;
  }
};

module.exports.getAutoCompleteSuggestions = async (input) => {
  if (!input) {
    throw new Error("query is required");
  }
  const apiKey = process.env.GOOGLE_MAPS_API_KEY;
  const url = `https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${encodeURIComponent(
    input
  )}&key=${apiKey}`;
  try {
    const response = await axios.get(url);
    if (response.data.status === "OK") {
      return response.data.predictions;
    } else {
      throw new Error("Unable to fetch suggestions");
    }
  } catch (error) {
    console.error(error);
    throw error;
  }
};

// module.exports.getCaptainsInTheRadius = async (
//   ltd,
//   lng,
//   radius,
//   vehicleTypeParam
// ) => {
//   // radius in km
//   const captains = await captainModel.find({
//     status: "online",
//     "vehicle.vehicleType": vehicleTypeParam,
//     location: {
//       $geoWithin: { $centerSphere: [[lng, ltd], radius / 6371] },
//     },
//   });

//   console.log("captains in radius --", vehicleTypeParam, captains);
//   return captains;
// };

// $geoWithin: { $centerSphere: [[ltd, lng], radius / 6371] },

// Haversine formula to calculate distance between 2 lat/lng points in KM
function distanceInKm(lat1, lng1, lat2, lng2) {
  const R = 6371; // Earth radius in km

  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;

  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);

  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; // distance in km
}

module.exports.getCaptainsInTheRadius = async (
  ltd,
  lng,
  radius,
  vehicleTypeParam
) => {
  // 1. Get all online captains of that vehicle type
  const allCaptains = await captainModel.find({
    status: "online",
    "vehicle.vehicleType": vehicleTypeParam,
  });

  // 2. Filter them by distance in JS
  const nearbyCaptains = allCaptains.filter((captain) => {
    if (
      !captain.location ||
      captain.location.ltd == null ||
      captain.location.lng == null
    ) {
      return false;
    }

    const captainLat = captain.location.ltd;
    const captainLng = captain.location.lng;
    console.log(
      "CAPTAIN LOCATION:",
      captain.location.ltd,
      captain.location.lng
    );

    const dist = distanceInKm(ltd, lng, captainLat, captainLng);

    console.log("DISTANCE(KM):", dist);
    return dist <= radius; // within radius km
  });

  console.log("USER PICKUP:", ltd, lng);

  console.log(
    "captains in radius --",
    vehicleTypeParam,
    nearbyCaptains.map((c) => ({
      id: c._id,
      lat: c.location.ltd,
      lng: c.location.lng,
    }))
  );

  return nearbyCaptains;
};
